# Ad Astra Custom Rocket Tiers — Minecraft 1.20.1

Rocket progression:
- Moon: Tier 1
- Mars: Tier 2
- Venus: Tier 3
- Mercury: Tier 4
- Glacio: Tier 5

Designed for Ad Astra 1.15.20 / Minecraft 1.20.1 with Ad Astra: Rocketed.

IMPORTANT:
These files override the planet data definitions. If your exact Ad Astra build has
different planet-data fields, use the matching original JSON and change only
`rocket_tier`.

Installation:
1. Put this folder in the world's `datapacks` folder, OR use a global datapack
   loader that loads datapacks for the instance.
2. Start the world.
3. Run `/reload`.
4. Check the rocket tiers in the Ad Astra planet selection screen.

